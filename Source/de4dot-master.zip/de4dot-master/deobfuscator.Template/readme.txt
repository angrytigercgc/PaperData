This is a template deobfuscator module. Make a copy and rename it to create your own deobfuscator modules with the required references and the correct build directories.
