/***
 * 
 *  ASMEX by RiskCare Ltd.
 * 
 * This source is copyright (C) 2002 RiskCare Ltd. All rights reserved.
 * 
 * Disclaimer:
 * This code is provided 'as is', with absolutely no warranty expressed or
 * implied.  Any use of this code is at your own risk.
 *   
 * You are hereby granted the right to redistribute this source unmodified
 * in its original archive. 
 * You are hereby granted the right to use this code, or code based on it,
 * provided that you acknowledge RiskCare Ltd somewhere in the documentation
 * of your application. 
 * You are hereby granted the right to distribute changes to this source, 
 * provided that:
 * 
 * 1 -- This copyright notice is retained unchanged 
 * 2 -- Your changes are clearly marked 
 * 
 * Enjoy!
 * 
 * --------------------------------------------------------------------
 * 
 * If you use this code or have comments on it, please mail me at 
 * support@jbrowse.com or ben.peterson@riskcare.com
 * 
 */

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Asmex
{
	/// <summary>
	/// Dialog for finding things -- ie for displaying/editing a FindState.
	/// </summary>
	internal class FindDialog : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox tbStr;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.CheckBox cbStartAtRoot;
		private System.Windows.Forms.CheckBox cbWhole;
		private System.Windows.Forms.CheckBox checkBox8;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.CheckBox cbType;
		private System.Windows.Forms.CheckBox cbMethod;
		private System.Windows.Forms.CheckBox cbParameter;
		private System.Windows.Forms.CheckBox cbField;
		private System.Windows.Forms.CheckBox cbResource;
		private System.Windows.Forms.CheckBox cbEvent;
		private System.Windows.Forms.CheckBox cbProperty;
		private System.Windows.Forms.CheckBox cbCaseful;
		
		private System.ComponentModel.Container components = null;

		public FindDialog(FindState f)
		{
			InitializeComponent();

			Find = f;	
		}

		public FindState Find
		{
			get
			{
				FindState f = new FindState();
				f.String = tbStr.Text;

				if (cbType.Checked)
					f.FindTypes = true;
				if (cbMethod.Checked)
					f.FindMethods = true;
				if (cbParameter.Checked)
					f.FindParameters = true;
				if (cbField.Checked)
					f.FindFields = true;
				if (cbResource.Checked)
					f.FindResources = true;
				if (cbProperty.Checked)
					f.FindProperties = true;
				if (cbEvent.Checked)
					f.FindEvents = true;

				if (cbWhole.Checked)
					f.WholeWord = true;

				if (cbStartAtRoot.Checked)
					f.StartAtRoot = true;

				if (cbCaseful.Checked)
					f.Caseful = true;

				return f;
			}

			set
			{
				if (value == null)
					value = new FindState();

				tbStr.Text = value.String;

				if (value.FindTypes)
					cbType.Checked = true;
				if (value.FindMethods)
					cbMethod.Checked = true;
				if (value.FindParameters)
					cbParameter.Checked = true;
				if (value.FindFields)
					cbField.Checked = true;
				if (value.FindEvents)
					cbEvent.Checked = true;
				if (value.FindResources)
					cbResource.Checked = true;
				if (value.FindProperties)
					cbProperty.Checked = true;
				if (value.FindEvents)
					cbEvent.Checked = true;


				if (value.WholeWord)
					cbWhole.Checked = true;

				if (value.StartAtRoot)
					cbStartAtRoot.Checked = true;

				if (value.Caseful)
					cbCaseful.Checked = true;

			}

		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FindDialog));
			this.tbStr = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.cbStartAtRoot = new System.Windows.Forms.CheckBox();
			this.cbWhole = new System.Windows.Forms.CheckBox();
			this.cbType = new System.Windows.Forms.CheckBox();
			this.cbMethod = new System.Windows.Forms.CheckBox();
			this.cbParameter = new System.Windows.Forms.CheckBox();
			this.cbField = new System.Windows.Forms.CheckBox();
			this.cbResource = new System.Windows.Forms.CheckBox();
			this.checkBox8 = new System.Windows.Forms.CheckBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.cbProperty = new System.Windows.Forms.CheckBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.cbCaseful = new System.Windows.Forms.CheckBox();
			this.cbEvent = new System.Windows.Forms.CheckBox();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// tbStr
			// 
			this.tbStr.Location = new System.Drawing.Point(88, 24);
			this.tbStr.Name = "tbStr";
			this.tbStr.Size = new System.Drawing.Size(280, 20);
			this.tbStr.TabIndex = 0;
			this.tbStr.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 24);
			this.label1.TabIndex = 8;
			this.label1.Text = "Search For:";
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(240, 208);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 10;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(128, 208);
			this.btnOK.Name = "btnOK";
			this.btnOK.TabIndex = 9;
			this.btnOK.Text = "OK";
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// cbStartAtRoot
			// 
			this.cbStartAtRoot.Location = new System.Drawing.Point(264, 80);
			this.cbStartAtRoot.Name = "cbStartAtRoot";
			this.cbStartAtRoot.Size = new System.Drawing.Size(152, 24);
			this.cbStartAtRoot.TabIndex = 12;
			this.cbStartAtRoot.Text = "Start From Root Of Tree";
			// 
			// cbWhole
			// 
			this.cbWhole.Location = new System.Drawing.Point(264, 104);
			this.cbWhole.Name = "cbWhole";
			this.cbWhole.Size = new System.Drawing.Size(152, 24);
			this.cbWhole.TabIndex = 13;
			this.cbWhole.Text = "Match Entire Name Only";
			// 
			// cbType
			// 
			this.cbType.Location = new System.Drawing.Point(32, 80);
			this.cbType.Name = "cbType";
			this.cbType.TabIndex = 14;
			this.cbType.Text = "Types";
			// 
			// cbMethod
			// 
			this.cbMethod.Location = new System.Drawing.Point(32, 104);
			this.cbMethod.Name = "cbMethod";
			this.cbMethod.TabIndex = 15;
			this.cbMethod.Text = "Methods";
			// 
			// cbParameter
			// 
			this.cbParameter.Location = new System.Drawing.Point(32, 128);
			this.cbParameter.Name = "cbParameter";
			this.cbParameter.TabIndex = 16;
			this.cbParameter.Text = "Parameters";
			// 
			// cbField
			// 
			this.cbField.Location = new System.Drawing.Point(136, 80);
			this.cbField.Name = "cbField";
			this.cbField.TabIndex = 18;
			this.cbField.Text = "Fields";
			// 
			// cbResource
			// 
			this.cbResource.Location = new System.Drawing.Point(120, 72);
			this.cbResource.Name = "cbResource";
			this.cbResource.TabIndex = 20;
			this.cbResource.Text = "Resources";
			// 
			// checkBox8
			// 
			this.checkBox8.Location = new System.Drawing.Point(264, 128);
			this.checkBox8.Name = "checkBox8";
			this.checkBox8.TabIndex = 21;
			this.checkBox8.Text = "Public Only";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.cbResource,
																					this.cbProperty});
			this.groupBox1.Location = new System.Drawing.Point(16, 56);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(232, 128);
			this.groupBox1.TabIndex = 22;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Search For:";
			// 
			// cbProperty
			// 
			this.cbProperty.Location = new System.Drawing.Point(16, 96);
			this.cbProperty.Name = "cbProperty";
			this.cbProperty.TabIndex = 25;
			this.cbProperty.Text = "Properties";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.cbCaseful});
			this.groupBox2.Location = new System.Drawing.Point(248, 56);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(176, 128);
			this.groupBox2.TabIndex = 23;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Options:";
			// 
			// cbCaseful
			// 
			this.cbCaseful.Location = new System.Drawing.Point(16, 96);
			this.cbCaseful.Name = "cbCaseful";
			this.cbCaseful.TabIndex = 25;
			this.cbCaseful.Text = "Case Sensitive";
			// 
			// cbEvent
			// 
			this.cbEvent.Location = new System.Drawing.Point(136, 104);
			this.cbEvent.Name = "cbEvent";
			this.cbEvent.TabIndex = 24;
			this.cbEvent.Text = "Events";
			// 
			// FindDialog
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(434, 245);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cbEvent,
																		  this.checkBox8,
																		  this.cbField,
																		  this.cbParameter,
																		  this.cbMethod,
																		  this.cbType,
																		  this.cbWhole,
																		  this.cbStartAtRoot,
																		  this.btnCancel,
																		  this.btnOK,
																		  this.label1,
																		  this.tbStr,
																		  this.groupBox1,
																		  this.groupBox2});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "FindDialog";
			this.Text = "Find";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnOK_Click(object sender, System.EventArgs e)
		{
			DialogResult = DialogResult.OK;
			Close();
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
			Close();
		}
	}
}
