struct _tiddata {
	UCHAR	Opaque[0x300];
};
