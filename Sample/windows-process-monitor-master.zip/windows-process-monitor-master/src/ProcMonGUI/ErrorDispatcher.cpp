#include "StdAfx.h"
#include "ErrorDispatcher.h"

ErrorDispatcher::ErrorDispatcher(void)
{
}

ErrorDispatcher::~ErrorDispatcher(void)
{
}
