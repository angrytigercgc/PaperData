# SNSpoofer

A tool to change or spoof hard disk hardware serial number, compatible with winxp/win7/win8/win10 x86 & x64 in a single executable bin.

-----------------------------------------------

# 硬盘序列号修改器

我做这个工具主要是为了无限免费使用迅游加速器。 o(∩_∩)o 

**界面使用SOUI做的**
<https://github.com/setoutsoft/soui>

# 截图

![](http://7xn2x9.com1.z0.glb.clouddn.com/aup/20160905.203002.348000.png)


![](http://7xn2x9.com1.z0.glb.clouddn.com/aup/20160905.203040.842000.png)




