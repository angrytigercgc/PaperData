#pragma once

NTSTATUS InitializeDevice(PDRIVER_OBJECT DriverObject);
NTSTATUS DestroyDevice();
