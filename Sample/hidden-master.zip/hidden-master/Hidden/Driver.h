#pragma once

VOID EnableDisableDriver(BOOLEAN enabled);
BOOLEAN IsDriverEnabled();
