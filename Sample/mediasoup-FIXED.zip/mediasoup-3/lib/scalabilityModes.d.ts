export declare type ScalabilityMode = {
    spatialLayers: number;
    temporalLayers: number;
    ksvc: boolean;
};
export declare function parse(scalabilityMode: string): ScalabilityMode;
//# sourceMappingURL=scalabilityModes.d.ts.map