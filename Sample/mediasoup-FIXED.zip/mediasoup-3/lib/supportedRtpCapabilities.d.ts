import { RtpCapabilities } from './RtpParameters';
declare const supportedRtpCapabilities: RtpCapabilities;
export { supportedRtpCapabilities };
//# sourceMappingURL=supportedRtpCapabilities.d.ts.map