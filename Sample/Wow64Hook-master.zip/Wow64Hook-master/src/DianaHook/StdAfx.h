#pragma once

#include <windows.h>
#include <assert.h>
#include <stdexcept>
