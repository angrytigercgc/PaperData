# Wow64Hook project

## About

This is a small test С++ project to show how can hook 64-bit code from Wow64 32-bit mode.

## How to build

To build solution you need:
- Visual Studio 2019 (with all SDK available in additional features);
- CMake tool to generate solution files and build project.

After installing all the necessary tools just run build.bat script.
