Plugins are specified in the [pom](../../../pom.xml) in `runtime` scope

