#pragma once
#include "../Config.h"

namespace blackbone
{
BLACKBONE_API bool InitializeOnce();
}