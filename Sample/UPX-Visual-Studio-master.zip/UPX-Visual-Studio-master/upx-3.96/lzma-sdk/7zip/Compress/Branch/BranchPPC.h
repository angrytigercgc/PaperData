// BranchPPC.h

#ifndef __BRANCH_PPC_H
#define __BRANCH_PPC_H

#include "BranchTypes.h"

UInt32 PPC_B_Convert(Byte *data, UInt32 size, UInt32 nowPos, int encoding);

#endif
