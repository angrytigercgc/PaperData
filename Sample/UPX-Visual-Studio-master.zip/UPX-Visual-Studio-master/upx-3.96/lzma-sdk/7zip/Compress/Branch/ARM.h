// ARM.h

#ifndef __ARM_H
#define __ARM_H

#include "BranchCoder.h"

MyClassA(BC_ARM, 0x05, 1)

#endif
