// HCMain.h

#define _HASH_CHAIN
#include "../BinTree/BinTreeMain.h"
#undef _HASH_CHAIN

