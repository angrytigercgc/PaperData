// BinTree2.h

#ifndef __BINTREE2_H
#define __BINTREE2_H

#define BT_NAMESPACE NBT2
#define BT_NO_HASH_MASK 1

#include "BinTreeMain.h"

#undef BT_NO_HASH_MASK
#undef BT_NAMESPACE

#endif
