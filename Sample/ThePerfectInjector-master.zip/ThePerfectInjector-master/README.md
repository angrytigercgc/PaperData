# ThePerfectInjector
Literally, the perfect injector.

Detailed explanation: https://blog.can.ac/2018/05/02/making-the-perfect-injector-abusing-windows-address-sanitation-and-cow/
