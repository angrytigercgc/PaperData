
// install_lsp.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// Cinstall_lspApp:
// See install_lsp.cpp for the implementation of this class
//

class Cinstall_lspApp : public CWinApp
{
public:
	Cinstall_lspApp();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern Cinstall_lspApp theApp;