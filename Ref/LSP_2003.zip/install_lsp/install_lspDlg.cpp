
// install_lspDlg.cpp : implementation file
//

#include "stdafx.h"
#include "install_lsp.h"
#include "install_lspDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include <winperf.h>   // for Windows NT
#include <tlhelp32.h>
#include <wchar.h>
#include <Ws2spi.h>

#define PROV_NAME		_T("LSP_PROV")
//#define PROV_PATH		_T("%SYSTEMROOT%\\system32\\LSPprov.dll")
#define PROV_PATH		_T("D:\\work\\network_work\\LSP_2003\\bin\\Debug\\lsp.dll")

// {4E91BE55-B39A-4549-BA6B-44BA937ED8C5}
static GUID ProviderGuid =
{ 0x4e91be55, 0xb39a, 0x4549,{ 0xba, 0x6b, 0x44, 0xba, 0x93, 0x7e, 0xd8, 0xc5 } };

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// Cinstall_lspDlg dialog



Cinstall_lspDlg::Cinstall_lspDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_INSTALL_LSP_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void Cinstall_lspDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(Cinstall_lspDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_INSTALL, &Cinstall_lspDlg::OnBnClickedBtnInstall)
	ON_BN_CLICKED(IDC_BTN_UNINSTALL, &Cinstall_lspDlg::OnBnClickedBtnUninstall)
END_MESSAGE_MAP()


// Cinstall_lspDlg message handlers

BOOL Cinstall_lspDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void Cinstall_lspDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Cinstall_lspDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Cinstall_lspDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void Cinstall_lspDlg::OnBnClickedBtnInstall()
{
	int rt = 0;
#ifdef _M_X64
	rt = InstallLSPProv(LspCatalogBoth, PROV_PATH);
	if (rt != 0)
	{
		MessageBox(_T("--- 64bit InstallProvider FAILED !!! ------\n"));
	}
#else
	rt = InstallLSPProv(LspCatalog32Only, PROV_PATH);
	if (rt != 0)
	{
		MessageBox(_T("--- 32bit InstallProvider FAILED !!! ------\n"));
	}
#endif
	PrintProviders();
}


void Cinstall_lspDlg::OnBnClickedBtnUninstall()
{
	UninstallLSPProv();
}

int Cinstall_lspDlg::InstallLSPProv(WINSOCK_CATALOG Catalog, CString sProvPath)
{
	int		inst_cnt = 0, i;
	DWORD	InstID[100] = { 0 };
	int		nID = m_provMng.FindProvider(Catalog, &ProviderGuid);
	if (nID < 0)
	{
		int		cnt;
		WSAPROTOCOL_INFOW	*pProto = m_provMng.GetProviders(Catalog, cnt);

		if (pProto)
		{
			for (i = 0; i<cnt; i++)
			{
				//int		id = pProto[i].dwCatalogEntryId;
				//CString	aName = pProto[i].szProtocol;
				if (pProto[i].iAddressFamily == AF_INET &&
					pProto[i].iSocketType == SOCK_STREAM)
				{
					if (wcsstr(pProto[i].szProtocol, L"[TCP/IP]"))
					{
						InstID[inst_cnt] = pProto[i].dwCatalogEntryId;
						inst_cnt++;
					}
				}
			}
			m_provMng.FreeProviders(pProto);
		}

		if (inst_cnt > 0)
		{
			/*UpdateData();
			CString	s;
			for (i=0; i<inst_cnt; i++)
			{
			s.Format(_T("%d\r\n"), InstID[i]);
			m_sLog += s;
			}
			UpdateData(FALSE);
			return;*/
			return m_provMng.InstallProvider(Catalog, &ProviderGuid, PROV_NAME, sProvPath.GetBuffer(0), InstID, inst_cnt);
		}
	}
	return 0;
}

void Cinstall_lspDlg::UninstallLSPProv()
{
	int		nID = m_provMng.FindProvider(LspCatalog32Only, &ProviderGuid);
	if (nID > 0)
		m_provMng.DeinstallProvider(LspCatalog32Only, nID);
#ifdef _M_X64
	nID = m_provMng.FindProvider(LspCatalog64Only, &ProviderGuid);
	if (nID > 0)
		m_provMng.DeinstallProvider(LspCatalog64Only, nID);
#endif
	PrintProviders();
}

void Cinstall_lspDlg::PrintProviders()
{
	int		cnt;
	WSAPROTOCOL_INFOW	*pProto = m_provMng.GetProviders(LspCatalog32Only, cnt);

	if (pProto)
	{
		OutputDebugStringW(L"-------------- 32 -------------------\n");
		for (int i = 0; i<cnt; i++)
		{
			int		id = pProto[i].dwCatalogEntryId;
			CString	aName = pProto[i].szProtocol;

			CString	sLog;
			sLog.Format(_T("%d - (%d,%d) : "), id, pProto[i].iProtocol, pProto[i].iSocketType);
			sLog = sLog + aName + _T("\n");
			OutputDebugStringW(sLog);
		}
		m_provMng.FreeProviders(pProto);
	}

#ifdef _M_X64
	pProto = m_provMng.GetProviders(LspCatalog64Only, cnt);

	if (pProto)
	{
		OutputDebugStringW(L"-------------- 64 -------------------\n");
		for (int i = 0; i<cnt; i++)
		{
			int		id = pProto[i].dwCatalogEntryId;
			CString	aName = pProto[i].szProtocol;

			CString	sLog;
			sLog.Format(_T("%d - (%d,%d) : "), id, pProto[i].iProtocol, pProto[i].iSocketType);
			sLog = sLog + aName + _T("\n");
			OutputDebugStringW(sLog);
		}
		m_provMng.FreeProviders(pProto);
	}
#endif
}

