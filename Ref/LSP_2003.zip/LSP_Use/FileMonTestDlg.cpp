
// FileMonTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FileMonTest.h"
#include "FileMonTestDlg.h"
#include "afxdialogex.h"
#include <winperf.h>   // for Windows NT
#include <tlhelp32.h>
#include <wchar.h>
#include <Ws2spi.h>

#define PROV_NAME		_T("LSP_PROV")
#define PROV_PATH		_T("%SYSTEMROOT%\\system32\\LSPprov.dll")

// {4E91BE55-B39A-4549-BA6B-44BA937ED8C5}
static GUID ProviderGuid = 
{ 0x4e91be55, 0xb39a, 0x4549, { 0xba, 0x6b, 0x44, 0xba, 0x93, 0x7e, 0xd8, 0xc5 } };


BOOL CFileMonTestDlg::OnInitDialog()
{
#ifdef _M_X64
	rt = InstallLSPProv(LspCatalogBoth, PROV_PATH);
	if (rt != 0)
	{
		MessageBox(_T("--- 64bit InstallProvider FAILED !!! ------\n"));
	}
#else
	rt = InstallLSPProv(LspCatalog32Only, PROV_PATH);
	if (rt != 0)
	{
		MessageBox(_T("--- 32bit InstallProvider FAILED !!! ------\n"));
	}
#endif
	PrintProviders();

	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CFileMonTestDlg::OnBnClickedUninst()
{
	UninstallLSPProv();
}


int CFileMonTestDlg::InstallLSPProv(WINSOCK_CATALOG Catalog, CString sProvPath)
{
	int		inst_cnt = 0, i;
	DWORD	InstID[100] = {0};
	int		nID = m_provMng.FindProvider(Catalog, &ProviderGuid);
	if (nID < 0)
	{
		int		cnt;
		WSAPROTOCOL_INFOW	*pProto = m_provMng.GetProviders(Catalog, cnt);

		if (pProto)
		{
			for (i=0; i<cnt; i++)
			{
				//int		id = pProto[i].dwCatalogEntryId;
				//CString	aName = pProto[i].szProtocol;
				if (pProto[i].iAddressFamily == AF_INET &&
					pProto[i].iSocketType == SOCK_STREAM)
				{
					if (wcsstr(pProto[i].szProtocol, L"[TCP/IP]"))
					{
						InstID[inst_cnt] = pProto[i].dwCatalogEntryId;
						inst_cnt ++;
					}
				}
			}
			m_provMng.FreeProviders(pProto);
		}

		if (inst_cnt > 0)
		{
			/*UpdateData();
			CString	s;
			for (i=0; i<inst_cnt; i++)
			{
				s.Format(_T("%d\r\n"), InstID[i]);
				m_sLog += s;
			}
			UpdateData(FALSE);
			return;*/
			return m_provMng.InstallProvider(Catalog, &ProviderGuid, PROV_NAME, sProvPath.GetBuffer(0), InstID, inst_cnt);
		}
	}
	return 0;
}

void CFileMonTestDlg::UninstallLSPProv()
{
	int		nID = m_provMng.FindProvider(LspCatalog32Only, &ProviderGuid);
	if (nID > 0)
		m_provMng.DeinstallProvider(LspCatalog32Only, nID);
#ifdef _M_X64
	nID = m_provMng.FindProvider(LspCatalog64Only, &ProviderGuid);
	if (nID > 0)
		m_provMng.DeinstallProvider(LspCatalog64Only, nID);
#endif
	PrintProviders();
}

void CFileMonTestDlg::PrintProviders()
{
	int		cnt;
	WSAPROTOCOL_INFOW	*pProto = m_provMng.GetProviders(LspCatalog32Only, cnt);

	if (pProto)
	{
		OutputDebugStringW(L"-------------- 32 -------------------\n");
		for (int i=0; i<cnt; i++)
		{
			int		id = pProto[i].dwCatalogEntryId;
			CString	aName = pProto[i].szProtocol;

			CString	sLog;
			sLog.Format(_T("%d - (%d,%d) : "), id, pProto[i].iProtocol, pProto[i].iSocketType);
			sLog = sLog + aName + _T("\n");
			OutputDebugStringW(sLog);
		}
		m_provMng.FreeProviders(pProto);
	}

#ifdef _M_X64
	pProto = m_provMng.GetProviders(LspCatalog64Only, cnt);

	if (pProto)
	{
		OutputDebugStringW(L"-------------- 64 -------------------\n");
		for (int i=0; i<cnt; i++)
		{
			int		id = pProto[i].dwCatalogEntryId;
			CString	aName = pProto[i].szProtocol;

			CString	sLog;
			sLog.Format(_T("%d - (%d,%d) : "), id, pProto[i].iProtocol, pProto[i].iSocketType);
			sLog = sLog + aName + _T("\n");
			OutputDebugStringW(sLog);
		}
		m_provMng.FreeProviders(pProto);
	}
#endif
}

