#pragma once

typedef enum
{
    LspCatalogBoth = 0,
    LspCatalog32Only,
    LspCatalog64Only
} WINSOCK_CATALOG;

#define DEFAULT_PATH_LEN        128
#define MAX_PROVIDERS           256     

#define MAX(a,b)                ( (a) > (b) ? (a) : (b) )
#define MIN(a,b)                ( (a) < (b) ? (a) : (b) )

// This structure is used to create the logical ordered LSP mappings
typedef struct _LSP_ENTRY
{
    WCHAR               wszLspDll[MAX_PATH];    // LSPs DLL name (and possible path)
    WSAPROTOCOL_INFOW   DummyEntry;             // Provider entry for dummy LSP entry

    WSAPROTOCOL_INFOW  *LayeredEntries;         // All layered providers beloging to LSP
    int                 Count;                  // Number of layered providers

    GUID               *LayeredGuids;           // List of GUIDs the LAYERED providers 
                                                //  are installed under (doesn't include
                                                //  the GUID the dummy entry is installed 
                                                //  under)
    int                 LayeredGuidCount;       // Number of GUIDs in the array

    int                 MaxChainLength;         // Used for sorting: the longest protocol
                                                //  chain of all the layered providers
    int                 LspOrder;               // Used for sorting: the lowest position
                                                //  within a layered entries protocol
                                                //  chain that a base provider sits
} LSP_ENTRY;

class CProvMng
{
public:
	CProvMng(void);
	~CProvMng(void);

	WSAPROTOCOL_INFOW* GetProviders(WINSOCK_CATALOG Catalog, int& iProtocolCount);
	void FreeProviders(WSAPROTOCOL_INFOW* pProtocolInfo);
	void DeinstallProvider( WINSOCK_CATALOG Catalog, int EntryId );

	int	FindProvider(WINSOCK_CATALOG Catalog, GUID* pGuid);
	int InstallProvider( WINSOCK_CATALOG Catalog, GUID* ProviderGuid, WCHAR* wszLspName, WCHAR* ProviderPath, DWORD* pdwCatalogIdArray, int dwCatalogIdArrayCount );
};

