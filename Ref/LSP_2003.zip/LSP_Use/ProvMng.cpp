#include "StdAfx.h"
#include "ProvMng.h"
#include <ws2spi.h>
#include <sporder.h>
#include <stdio.h>

LPWSCUPDATEPROVIDER  fnWscUpdateProvider=NULL;

#pragma comment(lib, "Rpcrt4.lib")
//
// Function: GetProviders
//
// Description:
//    This enumerates the Winsock catalog via the global variable ProtocolInfo.
//
LPWSAPROTOCOL_INFOW EnumerateProviders(WINSOCK_CATALOG Catalog, LPINT TotalProtocols)
{
	LPWSAPROTOCOL_INFOW ProtocolInfo = NULL;
	DWORD               ProtocolInfoSize = 0;
	INT                 ErrorCode,
                        rc;
    
    if (TotalProtocols == NULL)
        return NULL;

	*TotalProtocols = 0;

#ifdef _M_X64
	// Find out how many entries we need to enumerate
    if (Catalog == LspCatalog64Only)
    {
        // Find the size of the buffer
        rc = WSCEnumProtocols(NULL, ProtocolInfo, &ProtocolInfoSize, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            if (ErrorCode != WSAENOBUFS)
                return NULL;
        }

        // Allocate the buffer
        ProtocolInfo = (LPWSAPROTOCOL_INFOW) HeapAlloc(GetProcessHeap(), 0, ProtocolInfoSize);
        if (ProtocolInfo == NULL)
        {
            return NULL;
        }

        // Enumerate the catalog for real
        rc = WSCEnumProtocols(NULL, ProtocolInfo, &ProtocolInfoSize, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            HeapFree(GetProcessHeap(), 0, ProtocolInfo);
            return NULL;
        }

        // Update the count
        *TotalProtocols = rc;
    }
    else if (Catalog == LspCatalog32Only)
    {
        HMODULE            hModule;
        LPWSCENUMPROTOCOLS fnWscEnumProtocols32=NULL;

        // Load ws2_32.dll
        hModule = LoadLibrary(TEXT("ws2_32.dll"));
        if (hModule == NULL)
            return NULL;

        // Find the 32-bit catalog enumerator
        fnWscEnumProtocols32 = (LPWSCENUMPROTOCOLS)GetProcAddress(hModule, "WSCEnumProtocols32");
        if (fnWscEnumProtocols32 == NULL)
            return NULL;
        
        // Find the required buffer size
        rc = fnWscEnumProtocols32(NULL, ProtocolInfo, &ProtocolInfoSize, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            if (ErrorCode != WSAENOBUFS)
                return NULL;
        }

        // Allocate the buffer
        ProtocolInfo = (LPWSAPROTOCOL_INFOW)HeapAlloc(GetProcessHeap(), 0, ProtocolInfoSize);
        if (ProtocolInfo == NULL)
        {
            return NULL;
        }

        // Enumrate the catalog for real this time
        rc = fnWscEnumProtocols32(NULL, ProtocolInfo, &ProtocolInfoSize, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            HeapFree(GetProcessHeap(), 0, ProtocolInfo);
            return NULL;
        }

        // Update the count 
        *TotalProtocols = rc;

        FreeLibrary(hModule);
    }
#else
    if (Catalog == LspCatalog32Only)
    {
        // Find the size of the buffer
        rc = WSCEnumProtocols(NULL, ProtocolInfo, &ProtocolInfoSize, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            if (ErrorCode != WSAENOBUFS)
                return NULL;
        }

        // Allocate the buffer
        ProtocolInfo = (LPWSAPROTOCOL_INFOW) HeapAlloc(GetProcessHeap(), 0, ProtocolInfoSize);
        if (ProtocolInfo == NULL)
        {
            return NULL;
        }

        // Enumerate the catalog for real
        rc = WSCEnumProtocols(NULL, ProtocolInfo, &ProtocolInfoSize, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            HeapFree(GetProcessHeap(), 0, ProtocolInfo);
            return NULL;
        }

        // Update the count
        *TotalProtocols = rc;
    }
    else if (Catalog == LspCatalog64Only)
    {
        fprintf(stderr, "Unable to enumerate 64-bit Winsock catalog from 32-bit process!\n");
    }
#endif
    else
    {
        // Find the size of the buffer
        rc = WSCEnumProtocols(NULL, ProtocolInfo, &ProtocolInfoSize, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            if (ErrorCode != WSAENOBUFS)
                return NULL;
        }

        // Allocate the buffer
        ProtocolInfo = (LPWSAPROTOCOL_INFOW) HeapAlloc(GetProcessHeap(), 0, ProtocolInfoSize);
        if (ProtocolInfo == NULL)
        {
            return NULL;
        }

        // Enumerate the catalog for real
        rc = WSCEnumProtocols(NULL, ProtocolInfo, &ProtocolInfoSize, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            HeapFree(GetProcessHeap(), 0, ProtocolInfo);
            return NULL;
        }

        // Update the count
        *TotalProtocols = rc;
    }

	return ProtocolInfo;
}

//
// Function: FreeProviders
//
// Description:
//    This function frees the global catalog.
//
void FreeProviders(LPWSAPROTOCOL_INFOW ProtocolInfo)
{
	HeapFree(GetProcessHeap(), 0, ProtocolInfo);
}

//
// Function: FreeLspMap
//
// Description:
//    Frees all memory associated with an LSP_ENTRY array.
void
FreeLspMap(
    LSP_ENTRY *pLspMap,
    int iLspCount
    )
{
    int     i;

    for(i=0; i < iLspCount ;i++)
    {
        // Free the layered providers first
        if ( pLspMap[i].LayeredEntries != NULL )
            HeapFree(GetProcessHeap(), 0, pLspMap[i].LayeredEntries);
        if ( pLspMap[i].LayeredGuids != NULL )
            HeapFree(GetProcessHeap(), 0, pLspMap[i].LayeredGuids);
    }
    HeapFree(GetProcessHeap(), 0, pLspMap);
}

//
// Function: InstallProvider
//
// Description:
//    This is a wrapper for the WSCInstallProvider function. Depending on
//    which catalog is specified, this routine calls the correct install
//    routine.
//
int 
InstallProvider(
    WINSOCK_CATALOG Catalog,            // Which catalog are we operating on
    GUID *Guid,                         // GUID under which provider will be installed
    WCHAR *lpwszLspPath,                // Path to LSP's DLL
    WSAPROTOCOL_INFOW *pProvider,       // Array of provider structures to install
    INT iProviderCount                  // Number of providers in array
    )
{
    WSAPROTOCOL_INFOW *pEnumProviders=NULL;
    INT                iEnumProviderCount,
                       ErrorCode,
                       rc, i;

#ifdef _M_X64
    if (Catalog == LspCatalog32Only)
    {
        // Can't install only in 32-bit catalog from 64-bit
        fprintf(stderr, "\n\nError! It is not possible to install only in 32-bit catalog from 64-bit process!\n\n");
        return SOCKET_ERROR;
    }
    else if (Catalog == LspCatalog64Only)
    {
        // Just need to call WSCInstallProvider
        rc = WSCInstallProvider(Guid, lpwszLspPath, pProvider, iProviderCount, &ErrorCode);
    }
    else
    {
        // To install in both we must call WSCInstallProviderPath64_32
        rc = WSCInstallProvider64_32(Guid, lpwszLspPath, pProvider, iProviderCount, &ErrorCode);
    }
#else
    if (Catalog == LspCatalog32Only)
    {
        // From a 32-bit process we can only install into 32-bit catalog
        rc = WSCInstallProvider(Guid, lpwszLspPath, pProvider, iProviderCount, &ErrorCode);
    }
    else
    {
        // From a 32-bit process, we can't touch the 64-bit catalog at all
        fprintf(stderr, "\n\nError! It is not possible to install into the 64-bit catalog from a 32-bit process!\n\n");
        return SOCKET_ERROR;
    }
#endif
    if (rc == SOCKET_ERROR)
    {
        fprintf(stderr, "InstallProvider: WSCInstallProvider* failed: %d\n", ErrorCode);
    }

    // Go back and enumerate what we just installed
    pEnumProviders = EnumerateProviders(Catalog, &iEnumProviderCount);
    if (pEnumProviders != NULL)
    {
        for(i=0; i < iEnumProviderCount ;i++)
        {
            if (memcmp(&pEnumProviders[i].ProviderId, Guid, sizeof(GUID)) == 0)
            {
                printf("Installed: [%4d] %S\n", pEnumProviders[i].dwCatalogEntryId,
                    pEnumProviders[i].szProtocol);
            }
        }
        FreeProviders(pEnumProviders);
    }

    return rc;
}

//
// Function: DeinstallProvider
//
// Description:
//    This is a wrapper for the WSCDeinstallProvider* functions. Depending on
//    which Winsock catalog is specified, this routine calls the right uninstall
//    function.
//
int 
DeinstallProvider(
    WINSOCK_CATALOG Catalog,            // Which Winsock catalog to operate on
    GUID *Guid                          // GUID of provider to remove
    )
{
    INT     ErrorCode,
            rc;

#ifdef _M_X64
    if (Catalog == LspCatalogBoth)
    {
        // Remove from 64-bit catalog
        rc = WSCDeinstallProvider(Guid, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            if (ErrorCode != WSAEFAULT)
                fprintf(stderr, "DeinstallProvider: WSCDeinstallProvider failed: %d\n", ErrorCode);
        }

        // Remove from the 32-bit catalog
        rc = WSCDeinstallProvider32(Guid, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            if (ErrorCode != WSAEFAULT)
                fprintf(stderr, "DeinstallProvider: WSCDeinstallProvider32 failed: %d\n", ErrorCode);
        }
    }
    else if (Catalog == LspCatalog64Only)
    {
        // Remove from 64-bit catalog
        rc = WSCDeinstallProvider(Guid, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            if (ErrorCode != WSAEFAULT)
                fprintf(stderr, "DeinstallProvider: WSCDeinstallProvider failed: %d\n", ErrorCode);
        }
    }
    else
    {
        // Remove from the 32-bit catalog
        rc = WSCDeinstallProvider32(Guid, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            if (ErrorCode != WSAEFAULT)
                fprintf(stderr, "DeinstallProvider: WSCDeinstallProvider32 failed: %d\n", ErrorCode);
        }
    }
#else
    if (Catalog == LspCatalog32Only)
    {
        // Remove from the 32-bit catalog
        rc = WSCDeinstallProvider(Guid, &ErrorCode);
        if (rc == SOCKET_ERROR)
        {
            if (ErrorCode != WSAEFAULT)
                fprintf(stderr, "DeinstallProvider: WSCDeinstallProvider failed: %d\n", ErrorCode);
        }
    }
    else
    {
        fprintf(stderr, "Unable to remove providers in 64-bit catalog from 32-bit process!\n");
        return SOCKET_ERROR;
    }
#endif

    return NO_ERROR;
}

//
// Function: RemoveIdFromChain
//
// Description:
//    This function removes the given CatalogId from the protocol chain 
//    for pinfo.
//
int RemoveIdFromChain(WSAPROTOCOL_INFOW *pinfo, DWORD CatalogId)
{
    int     i, j;

    for(i=0; i < pinfo->ProtocolChain.ChainLen ;i++)
    {
        if (pinfo->ProtocolChain.ChainEntries[i] == CatalogId)
        {
            for(j=i; j < pinfo->ProtocolChain.ChainLen-1 ; j++)
            {
                pinfo->ProtocolChain.ChainEntries[j] = pinfo->ProtocolChain.ChainEntries[j+1];
            }
            pinfo->ProtocolChain.ChainLen--;
            return 0;
        }
    }
    return 1;
}


//
// Function: IsIdinChain
//
// Description:
//    This function determines whether the given catalog id is referenced
//    in the protocol chain of pinfo.
//
BOOL IsIdInChain(WSAPROTOCOL_INFOW *pinfo, DWORD Id)
{
    for(int i=0; i < pinfo->ProtocolChain.ChainLen ;i++)
    {
        if (pinfo->ProtocolChain.ChainEntries[i] == Id)
            return TRUE;
    }
    return FALSE;
}
//
// Function: GetProviderCount
//
// Description:
//    Returns the number of providers installed matching the given Provider Type.
//    The possible provider types are BASE_PROTOCOL or LAYERED_PROTOCOL. That is,
//    this function either returns the count of base providers or the number of
//    dummy LSP providers installed.
//
int
GetProviderCount(
    WSAPROTOCOL_INFOW *pProviders,
    int iProviderCount,
    int ProviderType
    )
{
    int Count, i;

    Count = 0;
    for(i=0; i < iProviderCount ;i++)
    {
        if ( pProviders[i].ProtocolChain.ChainLen == ProviderType )
            Count++;
    }
    return Count;
}

//
// Function: BuildLspMap
//
// Description:
//    This routine builds a map of all LSPs installed according to what order
//    they are in the catalog. That is, the information returned will be ordered
//    in the way the LSPs need to be installed. For example if LSP1 is installed
//    over the base TCP and UDP providers and LSP2 is installed over LSP1, then 
//    this routine will return two LSP_ENTRY structures with LSP1 first followed
//    by LSP2. The algorithm for determining the order is to first sort by where
//    a base provider ID occurs in an LSP chain with lower numbered ones first.
//    For example, LSP1 layered directly over TCP will have a base ID (TCP) in
//    chain position 1 while LSP (layered over LSP1) will have the base ID in
//    chain index 2. This is the ChainOrder field (and it is the minimum value
//    for all layered providers). After this first sort, it is possible to have
//    several LSPs with the same ChainOrder value. Within these groupings the
//    entries are sorted by the maximum LSP chain length. Each LSP has a number
//    of layered providers each with its own chain (and the chains could be
//    different lengths). The MaxChainLength value is the longest chain length
//    of all providers belonging to a given LSP. Each grouping of LspOrder is then
//    sorted by MaxChainLengthin ascending order.
//
LSP_ENTRY *
BuildLspMap(
    WSAPROTOCOL_INFOW *pProviders,
    int  iProviderCount,
    int *pLspCount
    )
{
    LSP_ENTRY *pLsps=NULL,
               lsptmp;
    DWORD     *pBaseList=NULL;
    BOOL       bFound;
    int        iLspCount=0,
               iBaseCount=0,
               iProviderPathLen,
               ErrorCode,
               LspOrder,
               start,
               end,
               idx,
               rc,
               i, j, k;

    iLspCount = GetProviderCount(pProviders, iProviderCount, LAYERED_PROTOCOL);

    if ( iLspCount == 0 )
    {
        // No LSPs installed, nothing to do
        goto cleanup;
    }

    // Allocate space for our structure which represents the LSPs installed
    pLsps = (LSP_ENTRY *) HeapAlloc(
            GetProcessHeap(),
            HEAP_ZERO_MEMORY,
            sizeof(LSP_ENTRY) * iLspCount
            );
    if (pLsps == NULL)
    {
        fprintf(stderr, "BuildLspMap: HeapAlloc failed: %d\n", GetLastError());
        goto cleanup;
    }

    idx = 0;
    for(i=0; i < iProviderCount ;i++)
    {
        if ( pProviders[i].ProtocolChain.ChainLen == LAYERED_PROTOCOL )
        {
            // Copy the dummy entry
            memcpy( &pLsps[idx].DummyEntry, &pProviders[i], sizeof(WSAPROTOCOL_INFOW) );

            // Get the DLL path
            iProviderPathLen = MAX_PATH-1;
            rc = WSCGetProviderPath(
                    &pLsps[idx].DummyEntry.ProviderId,
                     pLsps[idx].wszLspDll,
                    &iProviderPathLen,
                    &ErrorCode
                    );
            if (rc == SOCKET_ERROR)
            {
                fprintf(stderr, "BuildLspMap: WSCGetProviderPath failed: %d\n", ErrorCode);
                goto cleanup;
            }

            //
            // Now go find all the layered entries associated with the dummy provider
            //

            // First get the count
            for(j=0; j < iProviderCount ;j++)
            {
                if ( IsIdInChain( &pProviders[j], pLsps[idx].DummyEntry.dwCatalogEntryId ) )
                {
                    pLsps[idx].Count++;
                }
            }

            // Allocate space
            pLsps[idx].LayeredEntries = (WSAPROTOCOL_INFOW *)HeapAlloc(
                    GetProcessHeap(),
                    HEAP_ZERO_MEMORY,
                    sizeof(WSAPROTOCOL_INFOW) * pLsps[idx].Count
                    );
            if (pLsps[idx].LayeredEntries == NULL)
            {
                fprintf(stderr, "BuildLspMap: HeapAlloc failed: %d\n", GetLastError());
                goto cleanup;
            }

            // Now go find the entries
            pLsps[idx].Count = 0;
            for(j=0; j < iProviderCount ;j++)
            {
                if ( IsIdInChain( &pProviders[j], pLsps[idx].DummyEntry.dwCatalogEntryId ) )
                {
                    memcpy( &pLsps[idx].LayeredEntries[pLsps[idx].Count],
                            &pProviders[j],
                            sizeof(WSAPROTOCOL_INFOW)
                            );
                    
                    pLsps[idx].MaxChainLength = MAX( 
                            pLsps[idx].MaxChainLength,
                            pLsps[idx].LayeredEntries[pLsps[idx].Count].ProtocolChain.ChainLen 
                            );

                    // Keep track of how many GUIDs are used to install the layered entries
                    if (pLsps[idx].Count == 0)
                    {
                        pLsps[idx].LayeredGuids = (GUID *)HeapAlloc(
                                GetProcessHeap(),
                                HEAP_ZERO_MEMORY,
                                sizeof(GUID)
                                );
                        if (pLsps[idx].LayeredGuids == NULL)
                        {
                            fprintf(stderr, "BuildLspMap: HeapAlloc failed: %d\n", GetLastError());
                            goto cleanup;
                        }

                        memcpy( &pLsps[idx].LayeredGuids[0], &pProviders[j].ProviderId, sizeof(GUID) );
                        pLsps[idx].LayeredGuidCount++;
                    }
                    else
                    {
                        // See if we've already seen this guid
                        bFound = FALSE;
                        for(k=0; k < pLsps[idx].LayeredGuidCount ;k++)
                        {
                            if ( memcmp( &pLsps[idx].LayeredGuids[k],
                                         &pProviders[j].ProviderId,
                                         sizeof(GUID) ) == 0 )
                             {
                                bFound = TRUE;
                                break;
                             }
                        }
                        if (bFound == FALSE)
                        {
                            GUID    *tmpguid=NULL;

                            // New GUID -- we need to add it to the array
                            tmpguid = (GUID *)HeapAlloc(
                                    GetProcessHeap(),
                                    HEAP_ZERO_MEMORY,
                                    sizeof(GUID) * (pLsps[idx].LayeredGuidCount + 1)
                                    );
                            if (tmpguid == NULL)
                            {
                                fprintf(stderr, "BuildLspMap: HeapAlloc failed: %d\n", GetLastError());
                                goto cleanup;
                            }

                            memcpy( tmpguid, pLsps[idx].LayeredGuids, sizeof(GUID) * pLsps[idx].LayeredGuidCount );
                            memcpy( &tmpguid[pLsps[idx].LayeredGuidCount], &pProviders[j].ProviderId, sizeof(GUID) );

                            HeapFree(GetProcessHeap(), 0, pLsps[idx].LayeredGuids);

                            pLsps[idx].LayeredGuids = tmpguid;
                            pLsps[idx].LayeredGuidCount++;
                        }
                    }

                    pLsps[idx].Count++;

                }
            }

            pLsps[idx].LspOrder = MAX_PROTOCOL_CHAIN;

            idx++;
        }
    }

    //
    // We now have an array of "LSPs" -- now order them
    //

    // First get a list of base provider IDs
    iBaseCount = GetProviderCount(pProviders, iProviderCount, BASE_PROTOCOL);
    if (iBaseCount == 0)
    {
        fprintf(stderr, "BuildLspMap: GetProviderCount(BASE_PROTOCOL) returned zero!\n");
        goto cleanup;
    }

    // Allocate space for the array of base provider ID's
    pBaseList = (DWORD *) HeapAlloc(
            GetProcessHeap(),
            HEAP_ZERO_MEMORY,
            sizeof(DWORD) * iBaseCount
            );
    if (pBaseList == NULL)
    {
        fprintf(stderr, "BuildLspMap: HeapAlloc failed: %d\n", GetLastError());
        goto cleanup;
    }

    // Copy the base provider ID's to our array
    idx = 0;
    for(i=0; i < iProviderCount ;i++)
    {
        if ( pProviders[i].ProtocolChain.ChainLen == BASE_PROTOCOL )
        {
            pBaseList[idx++] = pProviders[i].dwCatalogEntryId;
        }
    }

    for(LspOrder = 1; LspOrder < MAX_PROTOCOL_CHAIN ;LspOrder++)
    {
        for(i=0; i < iLspCount ;i++)
        {
            for(j=0; j < pLsps[i].Count ;j++)
            {
                for(k=0; k < iBaseCount ;k++)
                {
                    if ( pLsps[i].LayeredEntries[j].ProtocolChain.ChainEntries[LspOrder] ==
                         pBaseList[k] )
                    {
                        pLsps[i].LspOrder = MIN( pLsps[i].LspOrder, LspOrder );
                        break;
                    }
                }
            }
        }
    }

    // Sort the entries according to the LspOrder field
    for(i=0; i < iLspCount ;i++)
    {
        for(j=i; j < iLspCount ;j++)
        {
            if ( pLsps[i].LspOrder > pLsps[j].LspOrder )
            {
                // Exchange positions
                memcpy( &lsptmp,   &pLsps[i], sizeof(LSP_ENTRY) );
                memcpy( &pLsps[i], &pLsps[j], sizeof(LSP_ENTRY) );
                memcpy( &pLsps[j], &lsptmp,   sizeof(LSP_ENTRY) );
            }
        }
    }

    // Now need to sort by MaxChainLength withing the LspOrder groupings

    for(LspOrder=1; LspOrder < MAX_PROTOCOL_CHAIN ;LspOrder++)
    {
        // Find the start and end positions within the array for the given
        // LspOrder value
        start = -1;
        end   = -1;
        for(i=0; i < iLspCount ;i++)
        {
            if ( pLsps[i].LspOrder == LspOrder)
            {
                start = i;
                break;
            }
        }
        if (start != -1)
        {
            for(j=start; j < iLspCount ;j++)
            {
                if ( pLsps[j].LspOrder != LspOrder)
                {
                    end = j-1;
                    break;
                }
            }
        }
        
        if ( (start != -1) && (end != -1) )
        {
            for(i=start; i < end ;i++)
            {
                for(j=i; j < end ;j++)
                {
                    if ( pLsps[i].MaxChainLength > pLsps[j].MaxChainLength )
                    {
                        memcpy( &lsptmp,   &pLsps[i], sizeof(LSP_ENTRY) );
                        memcpy( &pLsps[i], &pLsps[j], sizeof(LSP_ENTRY) );
                        memcpy( &pLsps[j], &lsptmp,   sizeof(LSP_ENTRY) );
                    }
                }
            }
        }
    }


cleanup:
    
    if (pLspCount)
        *pLspCount = iLspCount;

    if (pBaseList)
        HeapFree(GetProcessHeap(), 0, pBaseList);

    return pLsps;
}

//
// Function: PruneLspMap
//
// Description:
//    In the event WSCUpdateProvider is not available, the uninstaller must
//    remove and reinstall all dependent LSPs. After the LSP is removed, this
//    routine goes through the LSP map and removes any reference to provider
//    IDs belonging to the removed LSP (both base and layered provider IDs).
//    The pdwRemovedProviders is an array of provider IDs that belong to the
//    removed LSP.
//
void
PruneLspMap(
    LSP_ENTRY *pLspMap, 
    int iLspCount, 
    DWORD *pdwRemovedProviders, 
    int iRemoveCount
    )
{
    int i, j, k;

    // Go through all LSPs
    for(i=0; i < iLspCount ;i++)
    {
        // Go through all providers belonging to this LSP
        for(j=0; j < pLspMap[i].Count ;j++)
        {
            // Search for a removed provider
            for(k=0; k < iRemoveCount ;k++)
            {
                RemoveIdFromChain(&pLspMap[i].LayeredEntries[j], pdwRemovedProviders[k]);
            }
        }
    }
}

//
// Function: UpdateLspMap
//
// Description:
//   This routine updates catalog entry IDs in the LSP map. In the event
//   WSCUpdateProvider is not available, the uninstaller must remove all
//   dependent LSPs and reinstall them. This requires updating any references
//   to these reinstalled LSPs to their new values (as reinstalling a provider
//   changes the catalog ID). After a provider is LSP, the uninstaller matches
//   the older provider to the new to obtain the new provider ID (via
//   MapNewEntriesToOld). This routine takes and old provider ID and updates all
//   references within the LSP map to the new provider's ID.
//
void
UpdateLspMap(
    LSP_ENTRY *pLspMap,
    int iLspCount,
    DWORD dwOldValue,
    DWORD dwNewValue,
    DWORD *pdwCatalogOrder,
    int iProviderCount
    )
{
    int i, j, k;

    // Update the LSP_ENTRY mappings with the new value
    for(i=0; i < iLspCount ;i++)
    {
        // Go through all providers beloging to this LSP
        for(j=0; j < pLspMap[i].Count ;j++)
        {
            // Go through the protocol chain and update references if they match
            for(k=0; k < pLspMap[i].LayeredEntries[j].ProtocolChain.ChainLen ;k++)
            {
                if (pLspMap[i].LayeredEntries[j].ProtocolChain.ChainEntries[k] == dwOldValue)
                {
                    pLspMap[i].LayeredEntries[j].ProtocolChain.ChainEntries[k] = dwNewValue;
                }
            }
        }
    }

    // Update the provider order mapping
    for(i=0; i < iProviderCount ;i++)
    {
        if (pdwCatalogOrder[i] == dwOldValue)
            pdwCatalogOrder[i] =  dwNewValue;
    }
}

//
// Function: GetLayeredEntriesByGuid
//
// Description:
//    This routine is used by the uninstaller when WSCUpdateProvider is not 
//    available. If after an LSP is removed, there are other LSPs which depend
//    on that LSP, the uninstaller must remove and reinstall all LSPs and fix up
//    the catalog ID references within the protocol chain. This routine is used
//    when reinstalling LSP providers. Because the layered entries belonging to
//    an LSP may be installed either under unique (individual) GUIDs or whole
//    groups of providers may be installed under the same GUID. This routine
//    Takes an array of WSAPROTOCOL_INFOW entries belonging to one LSP and
//    returns an array of provider structures which match the given GUID.
//
WSAPROTOCOL_INFOW *
GetLayeredEntriesByGuid(
    WSAPROTOCOL_INFOW *pEntries, 
    int iEntryCount,
    GUID *MatchGuid, 
    int *iLayeredCount
    )
{
    WSAPROTOCOL_INFOW *MatchedEntries=NULL;
    int                count, 
                       i;

    // First count how many entries belong to this GUID
    count = 0;
    for(i=0; i < iEntryCount ;i++)
    {
        if ( memcmp( MatchGuid, &pEntries[i].ProviderId, sizeof(GUID)) == 0 )
        {
            count++;
        }
    }

    // Allocate space for the number of matching provider entries
    MatchedEntries = (WSAPROTOCOL_INFOW *)HeapAlloc(
            GetProcessHeap(),
            HEAP_ZERO_MEMORY,
            sizeof(WSAPROTOCOL_INFOW) * count
            );
    if (MatchedEntries == NULL)
    {
        fprintf(stderr, "GetLayeredEntriesByGuid: HeapAlloc failed: %d\n", GetLastError());
        return NULL;
    }

    // Go back and copy the matching providers into our array
    count = 0;
    for(i=0; i < iEntryCount ;i++)
    {
        if ( memcmp( MatchGuid, &pEntries[i].ProviderId, sizeof(GUID)) == 0 )
        {
            memcpy( &MatchedEntries[count++], &pEntries[i], sizeof(WSAPROTOCOL_INFOW) );
        }
    }

    // Update the return count
    if (iLayeredCount)
        *iLayeredCount = count;

    return MatchedEntries;
}

//
// Function: IsEqualProtocolEntries
//
// Description:
//    This routine compares two WSAPROTOCOL_INFOW structures to determine 
//    whether they are equal. This is done when a provider is uninstalled
//    and then reinstalled. After reinstallation we need to match the old
//    provider to the new (after reenumerating the catalog) so we can find
//    its new catalog ID. The fields used for determining a match are all
//    fields except the catalog ID (dwCatalogEntryId) and the protocol
//    string (szProtocol).
//
BOOL
IsEqualProtocolEntries(
    WSAPROTOCOL_INFOW *pInfo1,
    WSAPROTOCOL_INFOW *pInfo2
    )
{
    if ( (memcmp(&pInfo1->ProviderId, &pInfo2->ProviderId, sizeof(GUID)) == 0) &&
         (pInfo1->dwServiceFlags1 == pInfo2->dwServiceFlags1) &&
         (pInfo1->dwServiceFlags2 == pInfo2->dwServiceFlags2) &&
         (pInfo1->dwServiceFlags3 == pInfo2->dwServiceFlags3) &&
         (pInfo1->dwServiceFlags4 == pInfo2->dwServiceFlags4) &&
         (pInfo1->ProtocolChain.ChainLen == pInfo2->ProtocolChain.ChainLen) &&
         (pInfo1->iVersion == pInfo2->iVersion) &&
         (pInfo1->iAddressFamily == pInfo2->iAddressFamily) &&
         (pInfo1->iMaxSockAddr == pInfo2->iMaxSockAddr) &&
         (pInfo1->iMinSockAddr == pInfo2->iMinSockAddr) &&
         (pInfo1->iSocketType == pInfo2->iSocketType) &&
         (pInfo1->iProtocol == pInfo2->iProtocol) &&
         (pInfo1->iProtocolMaxOffset == pInfo2->iProtocolMaxOffset) &&
         (pInfo1->iNetworkByteOrder == pInfo2->iNetworkByteOrder) &&
         (pInfo1->iSecurityScheme == pInfo2->iSecurityScheme) &&
         (pInfo1->dwMessageSize == pInfo2->dwMessageSize)
       )
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//
// Function: MapNewEntriesToOld
//
// Description:
//    This routine is used by the uninstaller if WSCUpdateProvider is not available.
//    In this case, after one LSP is removed there may be others that referenced
//    that LSP. The uninstaller removes those entries and reinstalls them (and
//    removes the reference the the removed LSP). Once a dependent provider is
//    reinstalled we need to see if even other LSP references the reinstalled
//    provider and if so we need to update all references (catalog IDs) to that
//    LSP. This routine takes the Winsock catalog after a dependent LSP has
//    been resinstalled (pProvider and iProviderCount) and matches the newly
//    installed providers back to the LSP map we started with. This is so we
//    can get the older catalog ID along with the new catalog ID of each LSP
//    entry.
//
void
MapNewEntriesToOld(
    LSP_ENTRY *pEntry, 
    WSAPROTOCOL_INFOW *pProvider, 
    int iProviderCount
    )
{
    int     i, j;
            
    for(i=0; i < pEntry->Count ;i++)
    {
        for(j=0; j < iProviderCount ;j++)
        {
            if ( IsEqualProtocolEntries( &pEntry->LayeredEntries[i], &pProvider[j] ) )
            {
                pEntry->LayeredEntries[i].dwProviderReserved = pProvider[j].dwCatalogEntryId;
                break;
            }
        }
    }
}


//
// Function: RemoveProvider
//
// Description:
//    This function removes a layered provider. Things can get tricky if
//    we're removing a layered provider which has been layered over by 
//    another provider.
//
int RemoveProvider(WINSOCK_CATALOG Catalog, DWORD dwProviderId)
{
    WSAPROTOCOL_INFOW   *pProvider=NULL,
                        *pLayeredEntries=NULL;
    LSP_ENTRY           *pLspMap=NULL;
    DWORD               *pdwRemovedProviders=NULL,
                        *pdwCatalogOrder=NULL;
    INT                  iOriginalProviderCount=0,
                         iProviderCount=0,
                         iRemoveCount=0,
                         iLayerCount=0,
                         iLspCount=0,
                         ErrorCode,
                         Status,
                         rc, 
                         i, j;
    WCHAR                wszProviderPath[DEFAULT_PATH_LEN];
    INT                  iProviderPathLen=DEFAULT_PATH_LEN-1;

    Status = NO_ERROR;

    // Enumerate the catalog
    pProvider = EnumerateProviders(Catalog, &iProviderCount);
    if (pProvider == NULL)
    {
        fprintf(stderr, "RemoveProvider: Unable to enumerate catalog!\n");
        Status = SOCKET_ERROR;
        goto cleanup;
    }

    // Make sure this is a layered provider ID
    for(i=0; i < iProviderCount ;i++)
    {
        if ((pProvider[i].dwCatalogEntryId == dwProviderId) && 
            (pProvider[i].ProtocolChain.ChainLen == BASE_PROTOCOL))
        {
            fprintf(stderr, "\n\nError! Attempting to remove base provider: %S\n\n",
                pProvider[i].szProtocol);
            Status = SOCKET_ERROR;
            goto cleanup;
        }
    }

    // First count how many entries directly belong to this provider
    iRemoveCount = 0;
    for(i=0; i < iProviderCount ;i++)
    {
        if (((pProvider[i].ProtocolChain.ChainLen > 0) &&
             (pProvider[i].ProtocolChain.ChainEntries[0] == dwProviderId) ) ||
             (pProvider[i].dwCatalogEntryId == dwProviderId))
        {
            iRemoveCount++;
        }
    }

    // Save off the catalog entry IDs of the removed providers
    pdwRemovedProviders = (DWORD *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, iRemoveCount * sizeof(DWORD));
    if (pdwRemovedProviders == NULL)
    {
        fprintf(stderr, "\n\nError! HeapAlloc failed: %d\n", GetLastError());
        Status = SOCKET_ERROR;
        goto cleanup;
    }

    iRemoveCount = 0;

    // Uninstall the LSP dummy and chain entries
    for(i=0; i < iProviderCount ;i++)
    {
        if (((pProvider[i].ProtocolChain.ChainLen > 0) &&
             (pProvider[i].ProtocolChain.ChainEntries[0] == dwProviderId) ) || 
            (pProvider[i].dwCatalogEntryId == dwProviderId))
        {
            // Save removed catalog entry ID
            pdwRemovedProviders[iRemoveCount++] = pProvider[i].dwCatalogEntryId;

            // Display message and actually remove the provider
            printf("Removing: [%4d] %S\n", pProvider[i].dwCatalogEntryId,
                pProvider[i].szProtocol);
            DeinstallProvider(Catalog, &pProvider[i].ProviderId);
        }
    }

    // Enumerate the catalog again -- we may need to do more cleanup
    FreeProviders(pProvider);

    pProvider = EnumerateProviders(Catalog, &iProviderCount);
    if (pProvider == NULL)
    {
        fprintf(stderr, "RemoveProvider: Unable to enumerate Winsock catalog!\n");
        Status = SOCKET_ERROR;
        goto cleanup;
    }

    // If we're on Windows XP then life is easy
    if (fnWscUpdateProvider != NULL)
    {
        for(i=0; i < iProviderCount ;i++)
        {
            for(j=0; j < iRemoveCount ;j++)
            {
                if (IsIdInChain(&pProvider[i], pdwRemovedProviders[j]) == TRUE)
                {
                    // Remove the defunct LSP provider id
                    RemoveIdFromChain(&pProvider[i], pdwRemovedProviders[j]);

                    // Get the path to this provider
                    rc = WSCGetProviderPath(
                            &pProvider[i].ProviderId,
                            wszProviderPath,
                            &iProviderPathLen,
                            &ErrorCode
                            );
                    if (rc == SOCKET_ERROR)
                    {
                        fprintf(stderr, "RemoveProvider: WSCGetProviderPath failed: %d\n",
                                ErrorCode);
                        continue;
                    }

                    // Update it's provider entry
                    rc = fnWscUpdateProvider(
                            &pProvider[i].ProviderId,
                            wszProviderPath,
                            &pProvider[i],
                            1,
                            &ErrorCode
                            );
                    if (rc == SOCKET_ERROR)
                    {
                        fprintf(stderr, "RemoveProvider: WSCUpdateProvider failed: %d\n",
                                ErrorCode);
                    }
                    break;
                }
            }
        }

    }
    else
    {
        BOOL bDependent;

        // First check to see if any other LSPs were layered over ours
        bDependent = FALSE;
        for(i=0; (i < iProviderCount) && (!bDependent) ;i++)
        {
            for(j=0; j < iRemoveCount ;j++)
            {
                if ( IsIdInChain(&pProvider[i], pdwRemovedProviders[j]) )
                {
                    bDependent = TRUE;
                    break;
                }
            }
        }

        if (bDependent == TRUE)
        {
            // Yuck - need to fix up all the dependent providers layered
            // above our LSP. This is a lot more complicated without the
            // WSCUpdateProvider function. The problem is that to change
            // the protocol chains of the providers layered over the
            // removed LSP, you have to uninstall it, modify the chain,
            // and reinstall it. This itself isn't too bad but if there
            // are other LSPs layered over the one just re-installed, it
            // needs to be fixed now (since by re-isntalling the LSP, it
            // gets assigned a different provider ID).

            // In this case we're taking the "easy" way out. We will uninstall
            // ALL LSPs and reinstall them regardless of whether or not
            // they are dependent. Otherwise, the logic for determing which
            // other LSPs are affected by changes gets complicated and would
            // be prone to (more) errors.

            // First save off the catalog order

            // NOTE: iProviderCount is assumed to be an invariant throughout this
            //       process. If someone else is installing LSPs while we're doing
            //       this we'd be in trouble anyway.

            iOriginalProviderCount = iProviderCount;

            pdwCatalogOrder = (DWORD *)HeapAlloc(
                    GetProcessHeap(),
                    HEAP_ZERO_MEMORY,
                    sizeof(DWORD) * iOriginalProviderCount
                    );
            if (pdwCatalogOrder == NULL)
            {
                fprintf(stderr, "RemoveProvider: HeapAlloc failed: %d\n", GetLastError());
                goto cleanup;
            }

            for(i=0; i < iProviderCount ;i++)
            {
                pdwCatalogOrder[i] = pProvider[i].dwCatalogEntryId;
            }

            // Obtain the mapping of the LSP install order
            pLspMap = BuildLspMap(pProvider, iProviderCount, &iLspCount);
            if (pLspMap == NULL)
            {
                fprintf(stderr, "RemoveProvider: BuildLspMap returned NULL!\n");
                goto cleanup;
            }

            // Remove all instances of the removed LSP from the LSP map chains
            PruneLspMap(pLspMap, iLspCount, pdwRemovedProviders, iRemoveCount);

            // First uninstall all the LSPs
            for(i=0; i < iLspCount ;i++)
            {
                // Uninstall the dummy entry
                DeinstallProvider(Catalog, &pLspMap[i].DummyEntry.ProviderId);

                // Uninstall all the associated layered entries
                for(j=0; j < pLspMap[i].LayeredGuidCount ;j++)
                {
                    DeinstallProvider(Catalog, &pLspMap[i].LayeredGuids[j]);
                }
            }

            // No go back and re-install them
            for(i=0; i < iLspCount ;i++)
            {
                rc = InstallProvider(
                        Catalog, 
                       &pLspMap[i].DummyEntry.ProviderId, 
                        pLspMap[i].wszLspDll,
                       &pLspMap[i].DummyEntry, 
                        1
                        );
                if (rc != NO_ERROR)
                {
                    fprintf(stderr, "RemoveProvider: Unable to install dummy provider for %ws; error %d\n",
                        pLspMap[i].DummyEntry.szProtocol,
                        rc
                        );
                    goto cleanup;
                }

                // Enumerate the catalog 
                FreeProviders(pProvider);

                pProvider = EnumerateProviders(Catalog, &iProviderCount);
                if (pProvider == NULL)
                {
                    fprintf(stderr, "RemoveProvider: Unable to enumerate Winsock catalog!\n");
                    Status = SOCKET_ERROR;
                    goto cleanup;
                }

                // Find the new ID for the dummy entry
                for(j=0; j < iProviderCount ;j++)
                {
                    if ( memcmp( &pProvider[j].ProviderId, &pLspMap[i].DummyEntry.ProviderId, sizeof(GUID) ) == 0 )
                    {
                        // Save the new ID
                        pLspMap[i].DummyEntry.dwProviderReserved = pProvider[j].dwCatalogEntryId;
                        break;
                    }
                }

                // Go update all occurences of the old ID with the new ID
                UpdateLspMap(
                    pLspMap, 
                    iLspCount, 
                    pLspMap[i].DummyEntry.dwCatalogEntryId,
                    pLspMap[i].DummyEntry.dwProviderReserved,
                    pdwCatalogOrder,
                    iOriginalProviderCount
                    );

                // Install the layered entries associated with this LSP
                for(j=0; j < pLspMap[i].LayeredGuidCount ;j++)
                {
                    pLayeredEntries = GetLayeredEntriesByGuid(
                            pLspMap[i].LayeredEntries, 
                            pLspMap[i].Count,
                           &pLspMap[i].LayeredGuids[j], 
                           &iLayerCount
                            );
                    if (pLayeredEntries == NULL)
                    {
                        fprintf(stderr, "GetLayeredEntriesByGuid: Failed!\n");
                        continue;
                    }
                
                    // Reinstalled the layered entries
                    rc = InstallProvider(
                            Catalog, 
                           &pLspMap[i].LayeredGuids[j], 
                            pLspMap[i].wszLspDll,
                            pLayeredEntries,
                            iLayerCount
                            );
                    if (rc != NO_ERROR)
                    {
                        fprintf(stderr, "RemoveProvider: Unable to install layered provider(s) for %ws; error %d\n",
                            pLspMap[i].DummyEntry.szProtocol,
                            rc
                            );
                        goto cleanup;
                    }

                    HeapFree(GetProcessHeap(), 0, pLayeredEntries);
                    pLayeredEntries = NULL;
                }

                // Enumerate the catalog 
                FreeProviders(pProvider);

                pProvider = EnumerateProviders(Catalog, &iProviderCount);
                if (pProvider == NULL)
                {
                    fprintf(stderr, "RemoveProvider: Unable to enumerate Winsock catalog!\n");
                    Status = SOCKET_ERROR;
                    goto cleanup;
                }

                // Now go through and find the updated catalog entry IDs
                MapNewEntriesToOld(&pLspMap[i], pProvider, iProviderCount);

                // Now update the LSP map to reference these new IDs instead of the old
                for(j=0; j < pLspMap[i].Count ;j++)
                {
                    UpdateLspMap(
                        pLspMap, 
                        iLspCount, 
                        pLspMap[i].LayeredEntries[j].dwCatalogEntryId,
                        pLspMap[i].LayeredEntries[j].dwProviderReserved,
                        pdwCatalogOrder,
                        iOriginalProviderCount
                        );
                }
            }

            // Now all the LSPs are back in place -- we need to reorder the catalog
            // back to the way it was
            #ifdef _M_X64
            if (Catalog == LspCatalog32Only)
            {
                rc = WSCWriteProviderOrder32(pdwCatalogOrder, iProviderCount);
            }
            else
            {
                rc = WSCWriteProviderOrder(pdwCatalogOrder, iProviderCount);
            }
            #else
                rc = WSCWriteProviderOrder(pdwCatalogOrder, iProviderCount);
            #endif
            if (rc == SOCKET_ERROR)
            {
                fprintf(stderr, "RemoveProvider: WSCWriteProviderOrder failed: %d\n", WSAGetLastError());
            }

            printf("Catalog Order: ");
            for(i=0; i < iProviderCount ;i++)
            {
                printf("%d ", pdwCatalogOrder[i]);
            }
            printf("\n");

            // Free the catalog order info
            HeapFree(GetProcessHeap(), 0, pdwCatalogOrder);
            pdwCatalogOrder = NULL;
        }
    }

cleanup:

    //
    // Cleanup allocations
    //

    if (pLayeredEntries)
        HeapFree(GetProcessHeap(), 0, pLayeredEntries);

    if (pProvider)
        FreeProviders(pProvider);

    if (pdwRemovedProviders)
        HeapFree(GetProcessHeap(), 0, pdwRemovedProviders);

    if (pLspMap)
        FreeLspMap(pLspMap, iLspCount);

    if (pdwCatalogOrder)
        HeapFree(GetProcessHeap(), 0, pdwCatalogOrder);

    return Status;
}

//
// Function: CreateDummyEntry
//
// Description:
//    This creates a single WSAPROTOCOL_INFOW structure which describes the
//    hidden "dummy" entry for an LSP. This is required since the layered
//    chain entries must reference the catalog ID of the LSP and a catalog ID
//    cannot be obtained until an entry is installed.
//
WSAPROTOCOL_INFOW *
	CreateDummyEntry(
	WINSOCK_CATALOG Catalog, 
	INT CatalogId, 
	WCHAR *lpwszLspName
	)
{
	WSAPROTOCOL_INFOW *pProtocolInfo=NULL,
		*pDummyEntry=NULL;
	INT                iProtocolCount=0;
	int                i;

	// Enumerate the catalog
	pProtocolInfo = EnumerateProviders(Catalog, &iProtocolCount);
	if (pProtocolInfo == NULL)
	{
		fprintf(stderr, "CreateDummyEntry: EnumerateProviders failed!\n");
		return NULL;
	}

	// Find one of the providers we are layering over
	for(i=0; i < iProtocolCount ;i++)
	{
		if (pProtocolInfo[i].dwCatalogEntryId == CatalogId)
		{
			// Allocate space and copy the provider structure
			pDummyEntry = (WSAPROTOCOL_INFOW *)HeapAlloc(GetProcessHeap(), 0, sizeof(WSAPROTOCOL_INFOW));
			if (pDummyEntry == NULL)
			{
				return NULL;
			}

			// Copy the entry as a basis for the dummy entry
			memcpy(pDummyEntry, &pProtocolInfo[i], sizeof(WSAPROTOCOL_INFOW));

			break;
		}
	}

	// Verify we found a provider
	if (pDummyEntry == NULL)
	{
		fprintf(stderr, "\n\nError! Unable to find provider with ID of %d\n\n",
			CatalogId);
		return NULL;
	}

	// Remove the flag indicating IFS support (as our LSP does not provide IFS handles)
	pDummyEntry->dwServiceFlags1 &= (~XP1_IFS_HANDLES);
	// Set the flags indicating this is a hidden ("dummy") entry
	pDummyEntry->dwProviderFlags |= PFL_HIDDEN;
	pDummyEntry->ProtocolChain.ChainLen = LAYERED_PROTOCOL;

	// Copy the LSP name
	wcsncpy_s(pDummyEntry->szProtocol, lpwszLspName, WSAPROTOCOL_LEN);

	FreeProviders(pProtocolInfo);

	return pDummyEntry;
}

//
// Function: CreateLayeredEntries
//
// Description:
//    This finds all the providers the LSP is layering over and builds
//    the layered chain entries which make up the LSP. This routine 
//    returns the catalog ID of the LSP's dummy entry (because it is
//    needed to reorder the catlog after the chain entries are installed).
//
WSAPROTOCOL_INFOW * 
	CreateLayeredEntries(
	WINSOCK_CATALOG Catalog,        // Which catalog are we operating on
	WCHAR *lpwszLspName,            // Name of the LSP
	GUID *Guid,                     // GUID that the LSP's dummy entry was installed under
	DWORD *pdwIdArray,              // Array of catalog IDs we're layering over
	INT iIdArrayCount,              // Number of entries in array
	DWORD *LayeredId                // [OUT] Returns the catalog ID of dummy entry
	)
{
	WSAPROTOCOL_INFOW   *pProvider=NULL,
		*pLayeredEntries=NULL;
	DWORD                LayeredCatalogId=0;
	INT                  iProviderCount=0,
		idx,
		i, j, k;

	if (LayeredId == NULL)
		return NULL;

	// Enumerate the catalog
	pProvider = EnumerateProviders(Catalog, &iProviderCount);
	if (pProvider == NULL)
	{
		return NULL;
	}

	// Find the dummy entry so we can extract its catalog ID
	for(i=0; i < iProviderCount ;i++)
	{
		if (memcmp(&pProvider[i].ProviderId, Guid, sizeof(GUID)) == 0)
		{
			LayeredCatalogId = pProvider[i].dwCatalogEntryId;
			break;
		}
	}

	// Make sure we found the dummy provider
	if (LayeredCatalogId == 0)
	{
		fprintf(stderr, "CreateLayeredEntries: Unable to find dummy provider in catalog!\n");
		FreeProviders(pProvider);
		return NULL;
	}

	// Allocate space for our layered entries
	pLayeredEntries = (WSAPROTOCOL_INFOW *)HeapAlloc(GetProcessHeap(), 0, sizeof(WSAPROTOCOL_INFOW) * iIdArrayCount);
	if (pLayeredEntries == NULL)
	{
		fprintf(stderr, "CreateLayeredEntries: HeapAlloc failed: %d\n", GetLastError());
		FreeProviders(pProvider);
		return NULL;
	}

	// Go through the catalog and build the layered entries
	idx = 0;
	for(i=0; i < iProviderCount ;i++)
	{
		for(j=0; j < iIdArrayCount ;j++)
		{
			if (pProvider[i].dwCatalogEntryId == pdwIdArray[j])
			{
				memcpy(&pLayeredEntries[idx], &pProvider[i], sizeof(WSAPROTOCOL_INFOW));

				// Put our LSP name in the protocol field
				_snwprintf_s(pLayeredEntries[idx].szProtocol, WSAPROTOCOL_LEN,
					L"%s over [%s]",
					lpwszLspName,
					pProvider[i].szProtocol
					);
// 				_snwprintf(pLayeredEntries[idx].szProtocol, WSAPROTOCOL_LEN,
// 					L"%s over [%d]",
// 					lpwszLspName,
// 					pProvider[i].dwCatalogEntryId
// 					);

				// Move all the protocol chain entries down by 1 position
				for(k = pProvider[i].ProtocolChain.ChainLen; k > 0 ;k--)
				{
					pLayeredEntries[idx].ProtocolChain.ChainEntries[k] = pProvider[i].ProtocolChain.ChainEntries[k-1];
				}

				// The second entry is always the ID of the current pProvider[i]
				//     In case of multiple LSPs then if we didn't do this the [1] index
				//     would contain the ID of that LSP's dummy entry and not the entry
				//     itself.
				pLayeredEntries[idx].ProtocolChain.ChainEntries[1] = pProvider[i].dwCatalogEntryId;

				// Insert our LSP in the chain and increment the count
				pLayeredEntries[idx].ProtocolChain.ChainEntries[0] = LayeredCatalogId;
				pLayeredEntries[idx].ProtocolChain.ChainLen++;

				// Again, this LSP doesn't provide true IFS handles so remove the flag
				pLayeredEntries[idx].dwServiceFlags1 &= (~XP1_IFS_HANDLES);

				idx++;
			}
		}
	}

	FreeProviders(pProvider);

	// Return the ID of the LSP's dummy entry
	*LayeredId = LayeredCatalogId;

	return pLayeredEntries;
}

//
// Function: ReorderACatalog
//
// Description:
//    This routine enumerates a single catalog (32 or 64 bit) and reorders
//    the catalog according to the supplied catalog ID. That is, any provider
//    with that ID at the head of it's protocol chain is moved to the beginning
//    of the catalog.
//
DWORD *
ReorderACatalog(
    WINSOCK_CATALOG Catalog,
    DWORD   dwLayerId,
    INT   *dwEntryCount
    )
{
    WSAPROTOCOL_INFOW   *pProvider=NULL;
    DWORD               *pdwProtocolOrder=NULL;
    INT                  iProviderCount,
                         idx,
                         i;

    // Validate parameters
    if ((dwEntryCount == NULL) || (Catalog == LspCatalogBoth))
        return NULL;

    // Enumerate the catalog
    pProvider = EnumerateProviders(Catalog, &iProviderCount);
    if (pProvider == NULL)
    {
        fprintf(stderr, "ReorderACatalog: Unable to enumerate Winsock catalog!\n");
        goto cleanup;
    }

    // Allocate space for the array of catalog IDs (the catalog order)
    pdwProtocolOrder = (DWORD *)HeapAlloc(GetProcessHeap(), 0, sizeof(DWORD) * iProviderCount);
    if (pdwProtocolOrder == NULL)
    {
        fprintf(stderr, "ReorderACatalog: HeapAlloc failed: %d\n", GetLastError());
        goto cleanup;
    }

    idx = 0;

    // First put all the layered entries at the head of the catalog
    for(i=0; i < iProviderCount ;i++)
    {
        if (IsIdInChain(&pProvider[i], dwLayerId) == TRUE)
        {
            pdwProtocolOrder[idx++] = pProvider[i].dwCatalogEntryId;
        }
    }

    // Put the remaining entries after the layered chain entries
    for(i=0; i < iProviderCount ;i++)
    {
        if (IsIdInChain(&pProvider[i], dwLayerId) == FALSE)
        {
            pdwProtocolOrder[idx++] = pProvider[i].dwCatalogEntryId;
        }
    }

cleanup:

    if (pProvider)
        FreeProviders(pProvider);

    // Update the count
    *dwEntryCount = iProviderCount;


    return pdwProtocolOrder;
}

//
// Function: ReorderCatalog
//
// Description:
//    This routine reorders the Winsock catalog such that those entries
//    which reference the given catalog ID (dwLayerId) as the first entry
//    in the chain array occur at the head of the catalog. This routine
//    also operates on the specified Winsock catalog.
//
int ReorderCatalog(WINSOCK_CATALOG Catalog, DWORD dwLayeredId)
{
	DWORD     *pdwProtocolOrder;
	INT        iProviderCount,
		rc;

	rc = NO_ERROR;
#ifdef _WIN64
	if ((Catalog == LspCatalog32Only) || (Catalog == LspCatalogBoth))
	{
		printf("Reordering 32-bit Winsock catalog...\n");
		pdwProtocolOrder = ReorderACatalog(LspCatalog32Only, dwLayeredId, &iProviderCount);
		if (pdwProtocolOrder == NULL)
		{
			fprintf(stderr, "ReorderCatalog: ReorderACatalog failed!\n");
		}
		else
		{
			rc = WSCWriteProviderOrder32(pdwProtocolOrder, iProviderCount);
			if (rc == SOCKET_ERROR)
			{
				fprintf(stderr, "ReorderCatalog: WSCWriteProviderOrder32 failed: %d\n", rc);
			}

			HeapFree(GetProcessHeap(), 0, pdwProtocolOrder);
			pdwProtocolOrder = NULL;
		}
	}
	if ((Catalog == LspCatalog64Only) || (Catalog == LspCatalogBoth))
	{
		printf("Reordering 64-bit Winsock catalog...\n");
		pdwProtocolOrder = ReorderACatalog(LspCatalog64Only, dwLayeredId, &iProviderCount);
		if (pdwProtocolOrder == NULL)
		{
			fprintf(stderr, "ReorderCatalog: ReorderACatalog failed!\n");
		}
		else
		{
			rc = WSCWriteProviderOrder(pdwProtocolOrder, iProviderCount);
			if (rc == SOCKET_ERROR)
			{
				fprintf(stderr, "ReorderCatalog: WSCWriteProviderOrder failed: %d\n", rc);
			}

			HeapFree(GetProcessHeap(), 0, pdwProtocolOrder);
			pdwProtocolOrder = NULL;
		}
	}
#else
	if ((Catalog == LspCatalog32Only) || (Catalog == LspCatalogBoth))
	{
		printf("Reordering 32-bit Winsock catalog...\n");
		pdwProtocolOrder = ReorderACatalog(LspCatalog32Only, dwLayeredId, &iProviderCount);
		if (pdwProtocolOrder == NULL)
		{
			fprintf(stderr, "ReorderCatalog: ReorderACatalog failed!\n");
		}
		else
		{
			rc = WSCWriteProviderOrder(pdwProtocolOrder, iProviderCount);
			if (rc == SOCKET_ERROR)
			{
				fprintf(stderr, "ReorderCatalog: WSCWriteProviderOrder failed: %d\n", rc);
			}

			HeapFree(GetProcessHeap(), 0, pdwProtocolOrder);
			pdwProtocolOrder = NULL;
		}
	}
#endif

	return rc;
}

CProvMng::CProvMng(void)
{
	if (!fnWscUpdateProvider)
	{
		HMODULE	hModule = LoadLibraryA("ws2_32.dll");
		if (hModule)
		{
			fnWscUpdateProvider = (LPWSCUPDATEPROVIDER)GetProcAddress(hModule, "WSCUpdateProvider");
		}
	}
}

CProvMng::~CProvMng(void)
{
}

WSAPROTOCOL_INFOW* CProvMng::GetProviders( WINSOCK_CATALOG Catalog, int& iProtocolCount )
{
	WSAPROTOCOL_INFOW  *pProtocolInfo=NULL;
	iProtocolCount=0;

	pProtocolInfo = EnumerateProviders(Catalog, &iProtocolCount);
	return pProtocolInfo;
}

void CProvMng::FreeProviders( WSAPROTOCOL_INFOW* pProtocolInfo )
{
	::FreeProviders(pProtocolInfo);
}

void CProvMng::DeinstallProvider( WINSOCK_CATALOG Catalog, int EntryId )
{
	RemoveProvider(Catalog, EntryId);
//	throw std::exception("The method or operation is not implemented.");
}

int CProvMng::FindProvider(WINSOCK_CATALOG Catalog, GUID *pGuid )
{
	int		ret = -1;
	int		cnt;
	WSAPROTOCOL_INFOW	*pProto = GetProviders(Catalog, cnt);

	if (pProto)
	{
		for (int i=0; i<cnt; i++)
		{
			if (*pGuid == pProto[i].ProviderId)
			{
				ret = pProto[i].dwCatalogEntryId;
				break;
			}
		}
		FreeProviders(pProto);
	}
	return ret;
}

int CProvMng::InstallProvider( WINSOCK_CATALOG Catalog, GUID* ProviderGuid, WCHAR* wszLspName, WCHAR* ProviderPath, DWORD* pdwCatalogIdArray, int dwCatalogIdArrayCount )
{
	GUID ProviderChainGuid;
	DWORD   dwLayeredId;
	LPWSAPROTOCOL_INFOW pDummyEntry = NULL;
	LPWSAPROTOCOL_INFOW pLayeredEntries = NULL;
	// Create the 'dummy' protocol entry
	pDummyEntry = CreateDummyEntry(Catalog, pdwCatalogIdArray[0], wszLspName);
	if (pDummyEntry == NULL)
	{
		fprintf(stderr, "CreateDummyEntry failed!\n");
		goto cleanup;
	}

	// 'ProviderGuid' is the GUID for the dummy entry defined in lspguid.cpp

	//
	// NOTE: If you want to create multiple LSPs to install over each other
	//       you have to modify 2 files: lspguid.cpp and lsp.def. In lspguid.cpp
	//       you need to change to GUID to something unique and change the LSP
	//       name (e.g. lsp2.dll) and rebuild. The lsp.def file only needs the
	//       DLL name updated. Also note that the new instlsp.exe
	//       generated will only install lsp2.dll so keep it seperate from the
	//       original lsp.dll and instlsp.exe normally generated.
	//

	// Install the 'dummy' protocol entry for the LSP
	int	rc = ::InstallProvider(Catalog, ProviderGuid, ProviderPath, pDummyEntry, 1);
	if (rc != NO_ERROR)
	{
		fprintf(stderr, "Unable to install the dummy LSP entry!\n");
		goto cleanup;
	}

	// Don't need this struture any more
	HeapFree(GetProcessHeap(), 0, pDummyEntry);
	pDummyEntry = NULL;

#if 1
	// Create the layered chain entries
	pLayeredEntries = CreateLayeredEntries(Catalog, wszLspName, ProviderGuid, pdwCatalogIdArray, dwCatalogIdArrayCount, &dwLayeredId);
	if (pLayeredEntries == NULL)
	{
		fprintf(stderr, "Unable to create layered provider entries!\n");
		goto cleanup;
	}

	// Create a GUID for the protocol chain entries
	if (UuidCreate(&ProviderChainGuid) != RPC_S_OK)
	{
		fprintf(stderr, "UuidCreate failed: %d\n", GetLastError());
		goto cleanup;
	}

	// Install the layered chain providers
	rc = ::InstallProvider(Catalog, &ProviderChainGuid, ProviderPath, pLayeredEntries, dwCatalogIdArrayCount);
	if (rc != NO_ERROR)
	{
		fprintf(stderr, "Unable to install layered chain entries!\n");
		goto cleanup;
	}

	// Reorder the winsock catalog so the layered chain entries appear first
	rc = ReorderCatalog(Catalog, dwLayeredId);
	if (rc != NO_ERROR)
	{
		fprintf(stderr, "Unable to reorder Winsock catalog!\n");
		goto cleanup;
	}

	HeapFree(GetProcessHeap(), 0, pLayeredEntries);
	pLayeredEntries = NULL;
#else
	dwLayeredId = -1;
	int		iProviderCount = 0;
	LPWSAPROTOCOL_INFOW	pProvider = EnumerateProviders(Catalog, &iProviderCount);
	if (pProvider)
	{
		DWORD	CatIdArray[100];
		int		pos = 1;
		for (int i=0; i<iProviderCount; i++)
		{
			if (pProvider[i].ProviderId == *ProviderGuid)
			{
				CatIdArray[0] = pProvider[i].dwCatalogEntryId;
			}
			else
			{
				CatIdArray[pos] = pProvider[i].dwCatalogEntryId;
				pos ++;
			}
		}
		FreeProviders(pProvider);
		rc = WSCWriteProviderOrder(CatIdArray, iProviderCount);
		if (rc == SOCKET_ERROR)
		{
			fprintf(stderr, "ReorderCatalog: WSCWriteProviderOrder failed: %d\n", rc);
		}
	}

#endif
	return 0;
cleanup:
	if (pDummyEntry)
	{
		HeapFree(GetProcessHeap(), 0, pDummyEntry);
	}

	if (pLayeredEntries)
	{
		HeapFree(GetProcessHeap(), 0, pLayeredEntries);
	}
	return -1;
}
